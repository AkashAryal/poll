| Q                   | A
| --------------------| ---------------
| Type                | Bug / Support / Suggestion / Other
| Concorcet version   | x.y.z
| PHP version         | x.y.z
| Installation Method | Composer / __CondorcetAutoload.php / Custom

<!--
- Please fill in this template according to your issue.
- Please keep the table shown above at the top of your issue.
- Visit first the wiki https://github.com/julien-boudry/Condorcet/wiki if you are looking for support.
- Visit first https://github.com/julien-boudry/Condorcet/tree/master/Documentation if your are looking more accurate methods references documentation.
- For www.condorcet.vote service, please report to this repository : https://github.com/julien-boudry/Condorcet.Vote
- Otherwise, do not hesitate to open this ticket! Replace this comment by the description of your issue.
-->
