## public Candidate::getCreateTimestamp

### Description    

```php
public $Candidate -> getCreateTimestamp ( )
```

Get the timestamp corresponding of the creation of this candidate.    


### Return value:   

*(float)* Timestamp


---------------------------------------

### Related method(s)      

* [Candidate::getTimestamp](../Candidate%20Class/public%20Candidate--getTimestamp.md)    
