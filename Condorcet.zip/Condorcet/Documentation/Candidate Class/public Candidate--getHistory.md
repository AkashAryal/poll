## public Candidate::getHistory

### Description    

```php
public $Candidate -> getHistory ( )
```

Return an history of each namming change, with timestamp.    


### Return value:   

*(array)* An explicit multi-dimenssional array.


---------------------------------------

### Related method(s)      

* [Candidate::getCreateTimestamp](../Candidate%20Class/public%20Candidate--getCreateTimestamp.md)    
