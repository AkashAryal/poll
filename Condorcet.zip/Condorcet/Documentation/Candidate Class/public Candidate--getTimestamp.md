## public Candidate::getTimestamp

### Description    

```php
public $Candidate -> getTimestamp ( )
```

Get the timestamp corresponding of the last namming change.    


### Return value:   

*(float)* Timestamp


---------------------------------------

### Related method(s)      

* [Candidate::getCreateTimestamp](../Candidate%20Class/public%20Candidate--getCreateTimestamp.md)    
