## public Candidate::getName

### Description    

```php
public $Candidate -> getName ( )
```

Get the candidate name.    


### Return value:   

*(string)* Candidate name.


---------------------------------------

### Related method(s)      

* [Candidate::getHistory](../Candidate%20Class/public%20Candidate--getHistory.md)    
* [Candidate::setName](../Candidate%20Class/public%20Candidate--setName.md)    
