## public Vote::countRankingCandidates

### Description    

```php
public $Vote -> countRankingCandidates ( )
```

Count the number of candidate provide into the active Ranking set.    


### Return value:   

*(int)* Number of Candidate into ranking.

