## public Vote::getSimpleRanking

### Description    

```php
public $Vote -> getSimpleRanking ( )
```

Get the current ranking as a string format.    


### Return value:   

*(string)* String like 'A>D=C>B'


---------------------------------------

### Related method(s)      

* [Vote::getRanking](../Vote%20Class/public%20Vote--getRanking.md)    
