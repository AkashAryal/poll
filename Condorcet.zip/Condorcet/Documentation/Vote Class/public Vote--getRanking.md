## public Vote::getRanking

### Description    

```php
public $Vote -> getRanking ( )
```

Get the actual Ranking of this Vote.    


### Return value:   

*(array)* Multidimenssionnal array populated by Candidate object.


---------------------------------------

### Related method(s)      

* [Vote::setRanking](../Vote%20Class/public%20Vote--setRanking.md)    
