## public Vote::removeAllTags

### Description    

```php
public $Vote -> removeAllTags ( )
```

Remove all registered tag(s) on this Vote.    


### Return value:   

*(bool)* Return True.


---------------------------------------

### Related method(s)      

* [Vote::addTags](../Vote%20Class/public%20Vote--addTags.md)    
* [Vote::removeTags](../Vote%20Class/public%20Vote--removeTags.md)    
