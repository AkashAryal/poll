## public Timer\Manager::getHistory

### Description    

```php
public $Timer\Manager -> getHistory ( )
```

Return benchmarked actions history.    


### Return value:   

An explicit array with history.


---------------------------------------

### Related method(s)      

* [Election::getTimerManager](../Election%20Class/public%20Election--getTimerManager.md)    
