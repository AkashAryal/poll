## public Result::getResultAsArray

### Description    

```php
public $Result -> getResultAsArray ( [ bool convertToString = false] )
```

Get result as an array    


##### **convertToString:** *bool*   
Convert Candidate object to string    



### Return value:   

An ordered multidimensionnal array by rank.


---------------------------------------

### Related method(s)      

* [Election::getResult](../Election%20Class/public%20Election--getResult.md)    
* [Result::getResultAsString](../Result%20Class/public%20Result--getResultAsString.md)    
