## public Result::getBuildTimeStamp

### Description    

```php
public $Result -> getBuildTimeStamp ( )
```

Get the timestamp of this result.    


### Return value:   

(float) Microsecond timestamp.

