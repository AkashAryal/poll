## public Result::getCondorcetElectionGeneratorVersion

### Description    

```php
public $Result -> getCondorcetElectionGeneratorVersion ( )
```

Get the Condorcet PHP version that build this Result.    


### Return value:   

(string) Condorcet PHP version string format.

