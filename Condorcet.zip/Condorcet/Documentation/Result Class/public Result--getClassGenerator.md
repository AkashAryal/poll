## public Result::getClassGenerator

### Description    

```php
public $Result -> getClassGenerator ( )
```

Get the The algorithmic method used for this result.    


### Return value:   

(string) Method class path like Condorcet\Algo\Methods\Copeland


---------------------------------------

### Related method(s)      

* [Result::getMethod](../Result%20Class/public%20Result--getMethod.md)    
