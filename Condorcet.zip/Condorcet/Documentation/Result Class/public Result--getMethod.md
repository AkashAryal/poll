## public Result::getMethod

### Description    

```php
public $Result -> getMethod ( )
```

Get the The algorithmic method used for this result.    


### Return value:   

(string) Method name.


---------------------------------------

### Related method(s)      

* [Result::getClassGenerator](../Result%20Class/public%20Result--getClassGenerator.md)    
