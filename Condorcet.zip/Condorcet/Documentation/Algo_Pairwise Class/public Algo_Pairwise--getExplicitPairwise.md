## public Algo\Pairwise::getExplicitPairwise

### Description    

```php
public $Algo\Pairwise -> getExplicitPairwise ( )
```

Get an explicit pairwise.    


### Return value:   

An explicit array with candidate name as key.


---------------------------------------

### Related method(s)      

* [Election::getPairwise](../Election%20Class/public%20Election--getPairwise.md)    
