## public Election::countCandidates

### Description    

```php
public $Election -> countCandidates ( )
```

Count the number of registered candidate    


### Return value:   

(int) Number of registered candidate for this election.


---------------------------------------

### Related method(s)      

* [Election::getCandidatesList](../Election%20Class/public%20Election--getCandidatesList.md)    
