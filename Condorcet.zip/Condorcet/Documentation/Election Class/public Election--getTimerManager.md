## public Election::getTimerManager

### Description    

```php
public $Election -> getTimerManager ( )
```

Get the Timer manager object.    


### Return value:   

An Condorcet\Timer\Manager object using by this election.


---------------------------------------

### Related method(s)      

* [Election::getGlobalTimer](../Election%20Class/public%20Election--getGlobalTimer.md)    
* [Election::getLastTimer](../Election%20Class/public%20Election--getLastTimer.md)    
