## public Election::canAddCandidate

### Description    

```php
public $Election -> canAddCandidate ( mixed candidate )
```

Check if a Candidate is alredeay register. User strict Vote object comparaison, but also string namming comparaison into the election.    


##### **candidate:** *mixed*   
String or Condorcet/Vote object.    



### Return value:   

True if your Candidate is available. or False.


---------------------------------------

### Related method(s)      

* [Election::addCandidate](../Election%20Class/public%20Election--addCandidate.md)    
