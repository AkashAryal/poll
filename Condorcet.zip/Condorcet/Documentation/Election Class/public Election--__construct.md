## public Election::__construct

### Description    

```php
public $Election -> __construct ( )
```

Build a new Election.    


### Return value:   

NULL

